********************************************************************************
* Replication code for:
*   Kittel, Bernhard, Fabian Kalleitner, and Panos Tsakloglou. 2019.
*   "The Transmission of Work Centrality within the Family in a
*   Cross-Regional Perspective." The ANNALS of the American Academy of
*   Political and Social Science 682(1): 106-124.
*   https://doi.org/10.1177/0002716219827515
*
* File:     00_master.do
* Authors:  Fabian Kalleitner and Bernhard Kittel
* Purpose:  Sets the folder paths and runs all do files in order.
* Software: Stata 15 or later (written in 2018)
*
* Required user-written packages (install once):
*   ssc install outreg2
*   ssc install estout
*   ssc install coefplot
*   ssc install spmap
********************************************************************************

version 15
clear all
set more off

* Set these paths before running
global codedir "<path to this replication_code folder>"
global datadir "<path to the folder with the CUPESSE data files>"
global outdir  "<path to the folder for regression tables>"
global mapdir  "<path to the folder with reg-coordinate2.dta>"

do "$codedir/01_variables.do"
do "$codedir/02_analysis.do"
do "$codedir/03_maps.do"
