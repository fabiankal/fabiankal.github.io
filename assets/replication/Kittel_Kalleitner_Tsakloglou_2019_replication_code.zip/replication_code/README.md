# Replication code: The Transmission of Work Centrality within the Family in a Cross-Regional Perspective

Kittel, Bernhard, Fabian Kalleitner, and Panos Tsakloglou. 2019. "The Transmission of Work Centrality within the Family in a Cross-Regional Perspective." *The ANNALS of the American Academy of Political and Social Science* 682(1): 106–124. <https://doi.org/10.1177/0002716219827515>

This folder contains the Stata code for all tables, figures, and statistics reported in the paper and its online appendix. The code was written in 2018 by Fabian Kalleitner and Bernhard Kittel.

> **Note:** The code was written for the internal CUPESSE data version 0.22, merged with Eurostat NUTS-2 indicators. Variable and file names in the published CUPESSE data may differ, so the code may need to be adapted before it runs.

## Contents

| File | Purpose |
|------------------------------------|------------------------------------|
| `00_master.do` | Sets the folder paths and runs the other do files in order |
| `01_variables.do` | Constructs the individual-level variables for young adults and parents |
| `02_analysis.do` | Estimates the multilevel models and computes all reported statistics |
| `03_maps.do` | Draws the NUTS-2 maps in Figures 1 and 2 |

## Data

### CUPESSE survey data

The paper uses the youth and parent surveys of the CUPESSE project (Cultural Pathways to Economic Self-Sufficiency and Entrepreneurship). The data are available from the GESIS Data Archive after registration: <https://doi.org/10.4232/1.13042>. The analysis uses the nine EU member states in the data (Austria, Czech Republic, Denmark, Germany, Greece, Hungary, Italy, Spain, United Kingdom). Switzerland and Turkey are excluded in the code.

### Eurostat NUTS-2 indicators

The CUPESSE data must be merged with regional indicators for 2015 from Eurostat, using the respondents' NUTS-2 region (variable `geo`). The code expects the Eurostat variables to be named `y2015<indicator>`. The sources follow online appendix Table 1.

| Paper variable | Code variable | Eurostat table |
|------------------------|------------------------|------------------------|
| Percentage of employees in low human capital intensive sectors | `lower_class_jobs` (from `y2015C_LTC`, `y2015D_F`, `y2015LKIS`) | `htec_emp_reg2` |
| Youth unemployment rate, 15–24 | `NUTS2_YUE` (from `y20153rtT_Y15_24`) | `edat_lfse_22` |
| Long-term unemployment rate | `y2015PC_ACT` | `lfst_r_lfu2ltu` |
| Female labor force participation rate, 25–34 | `femecact25_34` (from `y2015F_Y25_34`) | `lfst_r_lfp2actrt` |

The merged file must be saved as `CUPESSE_Full_v022_merged.dta` in the data folder.

### Map files

`03_maps.do` needs two additional files that are not created by this code:

-   `CUPESSE_Full_v022_merged_Fabian_Annales_geo.dta` in the data folder: the output of `01_variables.do` merged with the map region identifiers `geoid2`, `stid`, and `nutsid`.
-   `reg-coordinate2.dta` in the map folder: a NUTS-2 coordinates file for `spmap`, which can be created from a Eurostat GISCO NUTS shapefile with `shp2dta`.

## Requirements

-   Stata 15 or later. Each do file sets `version 15`, so the older `table` syntax also runs in newer Stata versions.
-   User-written packages from SSC:

``` stata
ssc install outreg2
ssc install estout
ssc install coefplot
ssc install spmap
```

## How to run

1.  Prepare the data files described above.
2.  Open `00_master.do` and set the four folder paths: `codedir`, `datadir`, `outdir`, and `mapdir`.
3.  Run `00_master.do`.

The do files can also be run one at a time, as long as the globals from `00_master.do` are set first. `01_variables.do` must be run before the other two files.

## Where to find each result

| Paper | File | Section comment |
|------------------------|------------------------|------------------------|
| Figure 1 | `03_maps.do` | Figure 1 |
| Figure 2 | `03_maps.do` | Figure 2 |
| Intraclass correlations (Results section) | `02_analysis.do` | Results section: null models |
| Table 1 | `02_analysis.do` | Table 1 |
| Table 2 | `02_analysis.do` | Table 2 |
| Table 3 | `02_analysis.do` | Table 3 |
| Footnote 2 (Cronbach's alpha) | `02_analysis.do` | Footnote 2 |
| Footnote 4 | `02_analysis.do` | Footnote 4 |
| Footnote 6 | `02_analysis.do` | Footnote 6 |
| Online appendix Table 1 | `02_analysis.do` | Online appendix Table 1 |
| Online appendix Table 2 | `02_analysis.do` | Online appendix Table 2 |
| Online appendix Table 3 | `02_analysis.do` | Online appendix Table 3 |
| Online appendix Table 6 | `02_analysis.do` | Online appendix Table 6 |
| Online appendix Tables 7 and 8 | `02_analysis.do` | Online appendix Table 7 / Table 8 |

Regression tables are saved as `Table1.doc` to `Table3.doc` and `AppendixTable6.doc` to `AppendixTable8.doc` in the output folder. Figures are saved as `figure1` and `figure2` (`.tif` and `.eps`) in the map folder.

## Notes

-   The online appendix numbers tables 1 to 8. The paper text refers to the gender-separate models as Table A7 and to the RIWc models as Tables A7 and A8; in the appendix, these are Tables 6, 7, and 8.
