********************************************************************************
* Replication code for:
*   Kittel, Bernhard, Fabian Kalleitner, and Panos Tsakloglou. 2019.
*   "The Transmission of Work Centrality within the Family in a
*   Cross-Regional Perspective." The ANNALS of the American Academy of
*   Political and Social Science 682(1): 106-124.
*   https://doi.org/10.1177/0002716219827515
*
* File:     02_analysis.do
* Authors:  Fabian Kalleitner and Bernhard Kittel
* Purpose:  Estimates the multilevel models and computes all statistics
*           reported in the paper and the online appendix.
* Input:    $datadir/CUPESSE_Full_v022_merged_Fabian_Annales.dta
* Output:   Regression tables (.doc) in $outdir
* Software: Stata 15 or later (written in 2018)
*
* Note: This code was written for the internal CUPESSE data version 0.22
*       merged with Eurostat NUTS-2 indicators. Variable and file names may
*       differ in the published CUPESSE data. See README.md.
********************************************************************************

version 15

if "$datadir" == "" {
	display as error "Set the global datadir first (see 00_master.do)."
	exit 198
}

clear all
cd "$outdir"
use "$datadir/CUPESSE_Full_v022_merged_Fabian_Annales.dta", clear

* The paper uses the nine EU member states: Switzerland and Turkey are excluded
drop if CCODE== 1756 | CCODE== 1792

label define Country 1040 "Austria" 1203 "Czech Rep." 1208 "Denmark" 1276 "Germany" 1300 "Greece" 1348 "Hungary" 1380 "Italy" 1724 "Spain" 1826 "United Kingdom"
label values CCODE Country

sort CCODE

********************************************************************************
* NUTS-2 indicators (Eurostat, 2015)
********************************************************************************

* Youth unemployment rate, 15-24
gen NUTS2_YUE = y20153rtT_Y15_24
label variable NUTS2_YUE "Youth Unemployment Rate, NUTS2"
replace NUTS2_YUE = . if NUTS2_YUE<0

* Female labor force participation rate, 25-34 (Eurostat lfst_r_lfp2actrt)
gen femecact25_34 = y2015F_Y25_34
label variable femecact25_34 "Female Economic activity rate 25-34, NUTS2"

* Percentage of employees in low human capital intensive sectors (Eurostat htec_emp_reg2)
gen lower_class_jobs= (y2015C_LTC+y2015D_F+y2015LKIS)
label variable lower_class_jobs "Percentage Low-Perspective Jobs, NUTS2"

* The long-term unemployment rate (Eurostat lfst_r_lfu2ltu) enters the models
* directly as y2015PC_ACT

********************************************************************************
* Employment status combined with occupational skill level (Table 1, reference
* category: high-skilled employed). Employment status overrides the ISCO group.
********************************************************************************

replace isco_0 =. if isco_0<0
gen ISCO_EmpstatD =  isco_0
replace ISCO_EmpstatD = 4 if EmpStat == 2
replace ISCO_EmpstatD = 5 if EmpStat == 3
replace ISCO_EmpstatD = 6 if EmpStat == 4
replace ISCO_EmpstatD = . if EmpStat == .

label define ISCO_EmpstatD  1 "Mgr-Prof-Tech" 2 "Intermediate" 3 "Semi and Nonskilled" 4 "Unemployed" 5 "In Education/Training"  6 "Other"
label values ISCO_EmpstatD ISCO_EmpstatD

tab ISCO_EmpstatD EmpStat, missing

label variable Male "Male"
label variable PContWork "Parent Continue Work, binary"

********************************************************************************
* Descriptive statistics
********************************************************************************

* Online appendix Table 1: descriptive statistics
tabulate ISCO_EmpstatD, generate(ISCO_EmpstatD_g)
eststo summstats: estpost summarize WVe_fir01 ContWork WorkCent PWVe_fir01 PContWork Male Educ Child Migration ISCO_EmpstatD_g* FinSat lower_class_jobs NUTS2_YUE y2015PC_ACT femecact25_34 if (PContWork!=.| PWVe_fir01!=.) & geo!="-99" & PWVe_fir01!=. & lower_class_jobs!=. & NUTS2_YUE!=. & Male!=. & Educ!=. & Child!=. & Migration !=.  & FinSat !=. & ISCO_EmpstatD !=. & femecact25_34!=. & ISCO_EmpstatD!=.

* Online appendix Table 2: cross-tabulation of RIW and NEC with chi-squared and gamma
tab WVe_fir01 ContWork, chi2 V row
tab WVe_fir01 ContWork, chi gamma ce exp

* Footnote 2: Cronbach's alpha of the three work centrality items, overall and by country
alpha WVb_hum WVd_dut WVe_fir ,  std
sort CCODE
by CCODE: alpha WVb_hum WVd_dut WVe_fir ,  std item detail

* Online appendix Table 3: principal component analysis of the work centrality items and NEC
global xlist   WVb_hum  WVd_dut WVe_fir  ContWork

pca $xlist, mineigen(.9)
rotate, varimax

* Footnote 4: share of the regional variation explained by country differences (R-squared)
reg NUTS2_YUE i.CCODE
reg lower_class_jobs i.CCODE
reg femecact25_34 i.CCODE

* Footnote 6: correlation of female labor force participation and youth unemployment
cor femecact25_34 NUTS2_YUE

********************************************************************************
* Multilevel models
********************************************************************************

* Results section: null models and intraclass correlation coefficients without
* (first two models) and with country fixed effects (last two models). The if
* conditions hold N constant across all models of each dependent variable.
melogit WVe_fir01 if   geo!="-99" & PWVe_fir01!=. & lower_class_jobs!=. & NUTS2_YUE!=. & Male!=. & Educ!=. & Child!=. & Migration !=.  & FinSat !=. & ISCO_EmpstatD !=. & femecact25_34!=. || geo: ,
estat icc

melogit ContWork  if   geo!="-99" & PContWork!=. & lower_class_jobs!=. & NUTS2_YUE!=.  & Male!=. & Educ!=. & Child!=. & Migration !=. & FinSat !=. & ISCO_EmpstatD !=. & femecact25_34!=.  || geo: ,
estat icc

melogit WVe_fir01 i.CCODE if   geo!="-99" & PWVe_fir01!=. & lower_class_jobs!=. & NUTS2_YUE!=. & Male!=. & Educ!=. & Child!=. & Migration !=.  & FinSat !=. & ISCO_EmpstatD !=. & femecact25_34!=.  || geo: ,
estat icc

melogit ContWork  i.CCODE if   geo!="-99" & PContWork!=. & lower_class_jobs!=. & NUTS2_YUE!=.  & Male!=. & Educ!=. & Child!=. & Migration !=.  & FinSat !=. & ISCO_EmpstatD !=. & femecact25_34!=.  || geo: ,
estat icc

* Table 1: two-level random intercept logit models of RIW (column 1) and NEC (column 2)
melogit WVe_fir01 i.Male Educ i.Child Migration FinSat i.ISCO_EmpstatD PWVe_fir01  lower_class_jobs NUTS2_YUE  y2015PC_ACT c.femecact25_34 i.CCODE  if   geo!="-99" ||  geo:
est store Mod_RIW
melogit ContWork  i.Male Educ i.Child Migration FinSat i.ISCO_EmpstatD PContWork  lower_class_jobs NUTS2_YUE  y2015PC_ACT c.femecact25_34 i.CCODE  if   geo!="-99"  ||  geo:
est store Mod_NEC

outreg2 [Mod_RIW Mod_NEC] using Table1.doc, replace see auto(2) drop(1203.CCODE 1208.CCODE 1276.CCODE 1300.CCODE 1348.CCODE 1380.CCODE 1724.CCODE 1826.CCODE) label

* Table 2: level 2 estimates of RIW, models 1-6
melogit WVe_fir01  PWVe_fir01   i.Male Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" & lower_class_jobs!=. & NUTS2_YUE!=. &  y2015PC_ACT!=. & c.femecact25_34!=. ||  geo:
estat icc
est store Mod_RIWmacro0
melogit WVe_fir01 PWVe_fir01 lower_class_jobs i.Male Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" & lower_class_jobs!=. & NUTS2_YUE!=. &  y2015PC_ACT!=. & c.femecact25_34!=. ||  geo:
est store Mod_RIWmacro1
estat icc
melogit WVe_fir01 PWVe_fir01  NUTS2_YUE   i.Male Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" & lower_class_jobs!=. & NUTS2_YUE!=. &  y2015PC_ACT!=. & c.femecact25_34!=. ||  geo:
est store Mod_RIWmacro2
estat icc
melogit WVe_fir01 PWVe_fir01  y2015PC_ACT  i.Male Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" & lower_class_jobs!=. & NUTS2_YUE!=. &  y2015PC_ACT!=. & c.femecact25_34!=. ||  geo:
est store Mod_RIWmacro3
estat icc
melogit WVe_fir01 PWVe_fir01  c.femecact25_34 i.Male Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" & lower_class_jobs!=. & NUTS2_YUE!=. &  y2015PC_ACT!=. & c.femecact25_34!=. ||  geo:
est store Mod_RIWmacro4
estat icc
melogit WVe_fir01 PWVe_fir01 lower_class_jobs NUTS2_YUE  y2015PC_ACT c.femecact25_34 i.Male Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" ||  geo:
est store Mod_RIWmacro5
estat icc

outreg2 [Mod_RIWmacro0 Mod_RIWmacro1 Mod_RIWmacro2  Mod_RIWmacro3 Mod_RIWmacro4 Mod_RIWmacro5] using Table2.doc, replace see auto(2) drop(1203.CCODE 1208.CCODE 1276.CCODE 1300.CCODE 1348.CCODE 1380.CCODE 1724.CCODE 1826.CCODE) label

* Table 3: level 2 estimates of NEC, models 1-6
melogit ContWork   PContWork  i.Male Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" & lower_class_jobs!=. & NUTS2_YUE!=. &  y2015PC_ACT!=. & c.femecact25_34!=. ||  geo:
est store Mod_NECmacro0
estat icc
melogit ContWork   PContWork lower_class_jobs i.Male Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" & lower_class_jobs!=. & NUTS2_YUE!=. &  y2015PC_ACT!=. & c.femecact25_34!=. ||  geo:
est store Mod_NECmacro1
estat icc
melogit ContWork   PContWork  NUTS2_YUE   i.Male Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" & lower_class_jobs!=. & NUTS2_YUE!=. &  y2015PC_ACT!=. & c.femecact25_34!=. ||  geo:
est store Mod_NECmacro2
estat icc
melogit ContWork   PContWork  y2015PC_ACT  i.Male Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" & lower_class_jobs!=. & NUTS2_YUE!=. &  y2015PC_ACT!=. & c.femecact25_34!=. ||  geo:
est store Mod_NECmacro3
estat icc
melogit ContWork   PContWork  c.femecact25_34 i.Male Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" & lower_class_jobs!=. & NUTS2_YUE!=. &  y2015PC_ACT!=. & c.femecact25_34!=. ||  geo:
est store Mod_NECmacro4
estat icc
melogit ContWork  PContWork  lower_class_jobs NUTS2_YUE  y2015PC_ACT c.femecact25_34 i.Male Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99"  ||  geo:
est store Mod_NECmacro5
estat icc

outreg2 [Mod_NECmacro0 Mod_NECmacro1 Mod_NECmacro2  Mod_NECmacro3 Mod_NECmacro4 Mod_NECmacro5] using Table3.doc, replace see auto(2) drop(1203.CCODE 1208.CCODE 1276.CCODE 1300.CCODE 1348.CCODE 1380.CCODE 1724.CCODE 1826.CCODE) label

* Online appendix Table 6: gender-separate models of RIW and NEC
melogit WVe_fir01  PWVe_fir01 lower_class_jobs NUTS2_YUE y2015PC_ACT c.femecact25_34 Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" & Male==0 ||  geo:
est store Mod_RIW1
melogit WVe_fir01  PWVe_fir01 lower_class_jobs NUTS2_YUE y2015PC_ACT c.femecact25_34 Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" & Male==1 ||  geo:
est store Mod_RIW2
melogit ContWork   PContWork  lower_class_jobs NUTS2_YUE y2015PC_ACT c.femecact25_34 Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" & Male==0 ||  geo:
est store Mod_NEC1
melogit ContWork   PContWork  lower_class_jobs NUTS2_YUE y2015PC_ACT c.femecact25_34 Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" & Male==1 ||  geo:
est store Mod_NEC2

outreg2 [Mod_RIW1 Mod_RIW2  Mod_NEC1 Mod_NEC2] using AppendixTable6.doc, replace see auto(2) drop(1203.CCODE 1208.CCODE 1276.CCODE 1300.CCODE 1348.CCODE 1380.CCODE 1724.CCODE 1826.CCODE) label

* Online appendix Table 7: robustness check with the continuous work centrality
* index (RIWc) as dependent variable (footnote 2)
mixed WorkCent  PWVe_fir01 lower_class_jobs NUTS2_YUE y2015PC_ACT c.femecact25_34 i.Male Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" ||  geo:
outreg2 using AppendixTable7.doc, replace see auto(2) drop(1203.CCODE 1208.CCODE 1276.CCODE 1300.CCODE 1348.CCODE 1380.CCODE 1724.CCODE 1826.CCODE) label

* Online appendix Table 8: level 2 estimates of RIWc, models 1-6
mixed WorkCent  PWVe_fir01   i.Male Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" & lower_class_jobs!=. & NUTS2_YUE!=. &  y2015PC_ACT!=. & c.femecact25_34!=. ||  geo:
estat icc
est store WorkCentmacro0
mixed WorkCent PWVe_fir01 lower_class_jobs i.Male Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" & lower_class_jobs!=. & NUTS2_YUE!=. &  y2015PC_ACT!=. & c.femecact25_34!=. ||  geo:
est store WorkCentmacro1
estat icc
mixed WorkCent PWVe_fir01  NUTS2_YUE   i.Male Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" & lower_class_jobs!=. & NUTS2_YUE!=. &  y2015PC_ACT!=. & c.femecact25_34!=. ||  geo:
est store WorkCentmacro2
estat icc
mixed WorkCent PWVe_fir01  y2015PC_ACT  i.Male Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" & lower_class_jobs!=. & NUTS2_YUE!=. &  y2015PC_ACT!=. & c.femecact25_34!=. ||  geo:
est store WorkCentmacro3
estat icc
mixed WorkCent PWVe_fir01  c.femecact25_34 i.Male Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" & lower_class_jobs!=. & NUTS2_YUE!=. &  y2015PC_ACT!=. & c.femecact25_34!=. ||  geo:
est store WorkCentmacro4
estat icc
mixed WorkCent PWVe_fir01 lower_class_jobs NUTS2_YUE  y2015PC_ACT c.femecact25_34 i.Male Educ i.Child Migration FinSat i.ISCO_EmpstatD i.CCODE  if   geo!="-99" ||  geo:
est store WorkCentmacro5
estat icc

outreg2 [WorkCentmacro0 WorkCentmacro1 WorkCentmacro2  WorkCentmacro3 WorkCentmacro4 WorkCentmacro5] using AppendixTable8.doc, replace see auto(2) drop(1203.CCODE 1208.CCODE 1276.CCODE 1300.CCODE 1348.CCODE 1380.CCODE 1724.CCODE 1826.CCODE) label
