********************************************************************************
* Replication code for:
*   Kittel, Bernhard, Fabian Kalleitner, and Panos Tsakloglou. 2019.
*   "The Transmission of Work Centrality within the Family in a
*   Cross-Regional Perspective." The ANNALS of the American Academy of
*   Political and Social Science 682(1): 106-124.
*   https://doi.org/10.1177/0002716219827515
*
* File:     01_variables.do
* Authors:  Fabian Kalleitner and Bernhard Kittel
* Purpose:  Constructs the individual-level variables (young adults and
*           parents) used in the paper from the CUPESSE survey data.
* Input:    $datadir/CUPESSE_Full_v022_merged.dta
* Output:   $datadir/CUPESSE_Full_v022_merged_Fabian_Annales.dta
* Software: Stata 15 or later (written in 2018)
*
* Note: This code was written for the internal CUPESSE data version 0.22
*       merged with Eurostat NUTS-2 indicators. Variable and file names may
*       differ in the published CUPESSE data. See README.md.
********************************************************************************

version 15

if "$datadir" == "" {
	display as error "Set the global datadir first (see 00_master.do)."
	exit 198
}

clear all
use "$datadir/CUPESSE_Full_v022_merged.dta", clear

********************************************************************************
* Dependent variables
********************************************************************************

* Work values of young adults, rescaled to 0-1 (WVe_fir is the RIW item)
gen WVb_hum = (YQ21_b-1)/3 if YQ21_b >= 0
gen WVd_dut = (YQ21_d-1)/3 if YQ21_d >= 0
gen WVe_fir = (YQ21_e-1)/3 if YQ21_e >= 0

label variable WVb_hum "Work Values: Money without job is humiliating"
label variable WVd_dut "Work Values: Work is a duty to society"
label variable WVe_fir "Work Values: Work should come first, at expense of leisure"

* RIW: binary version of WVe_fir (0 = disagree, 1 = agree)
gen WVe_fir01 = .
replace WVe_fir01 = 0 if WVe_fir >= 0 & WVe_fir < 0.5
replace WVe_fir01 = 1 if WVe_fir >= 0.5 & WVe_fir <= 1
label variable WVe_fir01 "Work first, binary"
tab WVe_fir01

* NEC: would continue to work with enough money (1 = continue, 0 = stop)
gen ContWork = .
replace ContWork = 1 if YQ23 == 1
replace ContWork = 0 if YQ23 == 2
label variable ContWork "Continue work if enough money"

* RIWc: first principal component of WVb_hum, WVd_dut, and WVe_fir,
* rescaled to 0-1 (footnote 2, online appendix Tables 7 and 8)
pca WVb_hum WVd_dut WVe_fir
predict WorkCent
label variable WorkCent "Work Centrality"
sum WorkCent
replace WorkCent = WorkCent-r(min)
sum WorkCent
replace WorkCent = WorkCent/r(max)
sum WorkCent

********************************************************************************
* Parent work values
********************************************************************************

* Indicators for available mother and father questionnaires
gen mother=0
replace mother = 1 if PMCORD==1 | PMCORD==2 | PMCORD==-99
tab mother PMCORD
gen father=0
replace father = 1 if PFCORD==1 | PFCORD==2 | PFCORD==-99
tab father PFCORD

gen parent_domF = 0
replace parent_domF= 1 if father ==1
replace parent_domF= 2 if mother==1 & father != 1
label define parent_dom 0 "no parent data" 1 "father" 2 "mother"
label values parent_domF parent_dom

* Parent RIW: father's answer, mother's answer if missing
gen PWVe_fir = (PFQ18_e-1)/3 if PFQ18_e >= 0
replace PWVe_fir = (PMQ18_e-1)/3 if PWVe_fir == . & PMQ18_e >= 0

gen PWVe_fir01 = .
replace PWVe_fir01 = 0 if PWVe_fir >= 0 & PWVe_fir < 0.5
replace PWVe_fir01 = 1 if PWVe_fir >= 0.5 & PWVe_fir <= 1
label variable PWVe_fir01 "Parent work first, binary"
tab PWVe_fir01

* Parent NEC: father's answer if a father questionnaire is available,
* otherwise mother's answer
gen PContWork = .
replace PContWork = PMQ20 if PMQ20>0
replace PContWork = PFQ20 if PFQ20>0
replace PContWork = PMQ20 if parent_domF==2 & PMQ20>0
replace PContWork = PFQ20 if parent_domF==1 & PFQ20>0

replace PContWork = 0 if PContWork==2

label variable PContWork "Continue work if enough money parent"

********************************************************************************
* Individual-level controls
********************************************************************************

* Male (1 = male, 0 = female)
gen Male = .
replace Male = 0 if YQ42 == 2
replace Male = 1 if YQ42 == 1
label variable Male "Male Sex"

* Highest level of education completed (ES-ISCED, 1-7)
gen Educ = .
replace Educ = YQ18_II if YQ18_II >= 1 & YQ18_II <= 7
label variable Educ "Highest Level of Education Completed"
tab Educ

* Children (1 = at least one child)
gen Child = .
replace Child = 0 if YQ43b == 2
replace Child = 1 if YQ43b == 1
label variable Child "Children"
tab Child

* Migration background: young adult or at least one parent born abroad
capture drop Migration
capture drop MigrationY
gen MigrationY = .
replace MigrationY = 1 if YQ46a == 2
replace MigrationY = 0 if YQ46a == 1
label variable MigrationY "Youth born abroad"

gen MigrationM = .
replace MigrationM = 0 if YQ47_PM == CCODE & YQ47_PM >=0
replace MigrationM = 1 if YQ47_PM ~= CCODE & YQ47_PM >=0
label variable MigrationM "Mother born abroad"

gen MigrationF = .
replace MigrationF = 0 if YQ47_PF == CCODE & YQ47_PF >=0
replace MigrationF = 1 if YQ47_PF ~= CCODE & YQ47_PF >=0
label variable MigrationF "Father born abroad"

gen Migration = .
replace Migration = 1 if MigrationY == 1 | (MigrationM == 1 | MigrationF == 1)
replace Migration = 0 if MigrationY == 0 & MigrationM == 0 & MigrationF == 0
label variable Migration "Migration background"
tab Migration

* Financial satisfaction (1 = very dissatisfied, 4 = very satisfied)
gen FinSat = .
replace FinSat = YQ8 if YQ8 > 0 & YQ8 <= 4
label variable FinSat "Financial satisfaction"
tab FinSat

* Occupational group of the young adult (ISCO-08): isco_0 groups the
* 1-digit codes into high-skilled, intermediate, and semi/nonskilled
recode YQ15a_I_2d (10/19=1 "Managers") (20/29=2 "Professionals") (30/39=3 "Technicians") (40/49=4 "Clerical support workers") ///
(50/59=5 "Service and sales workers") (60/69=6 "Skilled agricultural") (70/79=7 "Craft and related trades workers") (80/89=8 "Plant and machine operators") ///
(90/99=9 "Elementary occupations") (-99=-99 "NA") (-98 -97 -96=-98 "DK"), gen(isco_1)
label variable isco_1 "ISCO_1"

recode isco_1 (1 2 3=1 "Mgr-Prof-Tech") (4 5 6=2 "Intermediate") (7 8 9=3 "Semi and Nonskilled") (-99=-99 "NA") (-98 -97 -96=-98 "DK"), gen(isco_0)
label variable isco_0 "ISCO_0"
tab isco_1 isco_0

* Employment status: main activity in the last month (YQ14b is used if
* several activities apply)
gen YQ14a_sum = YQ14a_1 + YQ14a_2 + YQ14a_3 + YQ14a_4 + YQ14a_5 + YQ14a_6 + YQ14a_7 + YQ14a_8 + YQ14a_9 + YQ14a_10
gen ES = .
replace ES = 1 if (YQ14a_1 == 1 & YQ14a_sum == 1) | (YQ14b == 1 & YQ14a_sum > 1)
replace ES = 2 if (YQ14a_2 == 1 & YQ14a_sum == 1) | (YQ14b == 2 & YQ14a_sum > 1)
replace ES = 3 if (YQ14a_3 == 1 & YQ14a_sum == 1) | (YQ14b == 3 & YQ14a_sum > 1)
replace ES = 4 if (YQ14a_4 == 1 & YQ14a_sum == 1) | (YQ14b == 4 & YQ14a_sum > 1)
replace ES = 5 if (YQ14a_5 == 1 & YQ14a_sum == 1) | (YQ14b == 5 & YQ14a_sum > 1)
replace ES = 6 if (YQ14a_6 == 1 & YQ14a_sum == 1) | (YQ14b == 6 & YQ14a_sum > 1)
replace ES = 7 if (YQ14a_7 == 1 & YQ14a_sum == 1) | (YQ14b == 7 & YQ14a_sum > 1)
replace ES = 8 if (YQ14a_8 == 1 & YQ14a_sum == 1) | (YQ14b == 8 & YQ14a_sum > 1)
replace ES = 9 if (YQ14a_9 == 1 & YQ14a_sum == 1) | (YQ14b == 9 & YQ14a_sum > 1)
replace ES = 10 if (YQ14a_10 == 1 & YQ14a_sum == 1) | (YQ14b == 10 & YQ14a_sum > 1)
label variable ES "Employment Status, all categories"

* Employment status, collapsed categories
gen EmpStat = .
replace EmpStat = 1 if ES == 1 | ES == 2
replace EmpStat = 2 if ES == 3
replace EmpStat = 3 if ES == 4 | ES == 5
replace EmpStat = 4 if ES > 5 & ES <= 10
label variable EmpStat "Employment Status"
label define EmpStatLabel 1 "Employed" 2 "Unemployed" 3 "In Education/Training" 4 "Other"
label values EmpStat EmpStatLabel
tab EmpStat

* Save the analysis data set
save "$datadir/CUPESSE_Full_v022_merged_Fabian_Annales.dta", replace
