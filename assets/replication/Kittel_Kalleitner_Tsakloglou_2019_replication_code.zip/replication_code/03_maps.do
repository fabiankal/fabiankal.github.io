********************************************************************************
* Replication code for:
*   Kittel, Bernhard, Fabian Kalleitner, and Panos Tsakloglou. 2019.
*   "The Transmission of Work Centrality within the Family in a
*   Cross-Regional Perspective." The ANNALS of the American Academy of
*   Political and Social Science 682(1): 106-124.
*   https://doi.org/10.1177/0002716219827515
*
* File:     03_maps.do
* Authors:  Fabian Kalleitner and Bernhard Kittel
* Purpose:  Draws the NUTS-2 maps of RIW (Figure 1) and NEC (Figure 2).
* Input:    $datadir/CUPESSE_Full_v022_merged_Fabian_Annales_geo.dta and
*           $mapdir/reg-coordinate2.dta
* Output:   figure1.tif/.eps and figure2.tif/.eps in $mapdir
* Software: Stata 15 or later (written in 2018)
*
* Note: This code was written for the internal CUPESSE data version 0.22
*       merged with Eurostat NUTS-2 indicators. Variable and file names may
*       differ in the published CUPESSE data. See README.md.
********************************************************************************

version 15

if "$datadir" == "" {
	display as error "Set the global datadir first (see 00_master.do)."
	exit 198
}

clear
set more off
cap log close

cd "$mapdir"

use "$datadir/CUPESSE_Full_v022_merged_Fabian_Annales_geo.dta", clear

* The paper uses the nine EU member states: Switzerland and Turkey are excluded
drop if CCODE== 1756 | CCODE== 1792

* Figure 1: share of young adults with high RIW by NUTS-2 region (N = 15,949).
* The Canary Islands (ES70) are not shown.
bysort geoid2 : egen WVe_fir01_g=mean(WVe_fir01)
gen WVe_fir01_g_r =round(WVe_fir01_g,.01)

spmap WVe_fir01_g_r using "reg-coordinate2.dta" if stid>0 & nutsid==1 & geo!="ES70", id(stid) ///
fcolor(Greys2)  osize(vvthin  ..) ndfcolor(white) ndsize(vvthin)  clnumber(6)  legstyle(2)  ///
legend(ring(0)   position(2) bmargin(large)) ysize(3) xsize(4)
graph export figure1.tif, width(4000) replace
graph export figure1.eps,  replace

* Figure 2: share of young adults with NEC by NUTS-2 region (N = 13,658).
* The Canary Islands (ES70) are not shown.
bysort geoid2 : egen ContWork_g=mean(ContWork)
gen ContWork_g_r =round(ContWork_g,.01)

spmap ContWork_g_r using "reg-coordinate2.dta" if stid>0 & nutsid==1 & geo!="ES70" , id(stid) ///
fcolor(Greys2)  osize(vvthin  ..) ndfcolor(white) ndsize(vvthin)  clnumber(6)  legstyle(2)  ///
legend(ring(0)   position(2) bmargin(large)) ysize(3) xsize(4)
graph export figure2.tif, width(4000) replace
graph export figure2.eps,  replace
