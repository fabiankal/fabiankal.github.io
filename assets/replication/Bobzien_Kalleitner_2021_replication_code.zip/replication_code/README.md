# Replication code: Attitudes towards European Financial Solidarity during the Covid-19 Pandemic

Bobzien, Licia, and Fabian Kalleitner. 2021. "Attitudes towards European Financial Solidarity during the Covid-19 Pandemic: Evidence from a Net-contributor Country." *European Societies* 23(sup1): S791–S804. <https://doi.org/10.1080/14616696.2020.1836669>

This folder contains the R code for all figures, tables, and statistics reported in the paper and its online appendix.

## Contents

| File | Purpose |
|------------------------------------|------------------------------------|
| `01_recoding_ACPP.Rmd` | Selects and renames the variables used in the paper and reshapes them into a long panel data set (waves 7 and 12) |
| `02_analysis.Rmd` | Produces Figure 1, Table 1, the t-tests reported in the text, and the online appendix tables and figure |

## Data

The paper uses waves 7 (8–13 May 2020) and 12 (26 June–1 July 2020) of the Austrian Corona Panel Project (ACPP). The data are available from the Austrian Social Science Data Archive (AUSSDA) after registration: <https://doi.org/10.11587/28KQNS>.

Save the ACPP Scientific Use File (SPSS format) as `data/raw/ACPP.sav` inside this folder.

## Requirements

R with the following packages:

``` r
install.packages(c("tidyverse", "haven", "panelr", "srvyr", "ggthemes", "plm", "stargazer"))
```

## How to run

1.  Save the ACPP data as `data/raw/ACPP.sav`.
2.  Knit (or run) `01_recoding_ACPP.Rmd`. This creates `data/processed/ACPP_recoded.rds`.
3.  Knit (or run) `02_analysis.Rmd`. Tables and figures are saved in `output/`.

Both files use paths relative to this folder, so run them with this folder as the working directory.

## Where to find each result

All results are produced by `02_analysis.Rmd`.

| Paper | Section | Output file |
|------------------------|------------------------|------------------------|
| Figure 1 | Figure 1 | `figure1.png`, `.svg`, `.eps` |
| Shares and t-tests reported in the text | Figure 1 | printed output |
| Table 1 | Regression models | `Table1.doc` |
| Online appendix Table 1 | Appendix Tables 1-3 | `Summary_statistics_atrittion_missings.doc` |
| Online appendix Table 2 | Appendix Tables 1-3 | `Regression_appendix_missings.doc` |
| Online appendix Table 3 | Appendix Tables 1-3 | `Summary_statistics_within_variation.doc` |
| Online appendix Figure 1 | Figure 1 | `appendix_figure1.png` |
| Online appendix Table 4 | Regression models | `Appendix_Table4.doc` |
| Online appendix Table 5 | Regression models | `Appendix_Table5.doc` |

## Notes

-   The variables are recoded for the regressions so that higher values indicate stronger support or agreement. The dependent variables range from -2 (very much against) to 2 (very much in favour).
-   The analysis code relies on the German value labels of the ACPP data (for example `"3 = Teils-teils"` and the party names in `SD_NRVOTE2019`). Check these labels if you use a different version of the data.
